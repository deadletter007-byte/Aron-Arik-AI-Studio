package com.aronarik.aistudio

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private var selectedBitmap: Bitmap? = null
    private lateinit var imageView: ImageView
    private lateinit var keyInput: EditText
    private lateinit var promptInput: EditText
    private lateinit var status: TextView
    private lateinit var chooseButton: Button
    private lateinit var runButton: Button

    private val imagePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                contentResolver.openInputStream(uri)?.use { stream ->
                    selectedBitmap = BitmapFactory.decodeStream(stream)
                    imageView.setImageBitmap(selectedBitmap)
                    status.text = "ছবি নির্বাচন করা হয়েছে"
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(22, 25, 36)
        window.navigationBarColor = android.graphics.Color.rgb(22, 25, 36)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(android.graphics.Color.rgb(245, 246, 250))
        }
        val title = TextView(this).apply {
            text = "Aron & Arik AI Studio"
            textSize = 24f
            setTextColor(android.graphics.Color.rgb(28, 32, 48))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        root.addView(title, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        keyInput = EditText(this).apply {
            hint = "Gemini API key দিন"
            singleLine = true
            inputType = 129
        }
        root.addView(keyInput, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        chooseButton = Button(this).apply {
            text = "ছবি নির্বাচন করুন"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                imagePicker.launch(intent)
            }
        }
        root.addView(chooseButton, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        imageView = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        root.addView(imageView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        promptInput = EditText(this).apply {
            hint = "ছবিতে কী পরিবর্তন চান লিখুন"
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP
        }
        root.addView(promptInput, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        runButton = Button(this).apply {
            text = "Gemini দিয়ে চেষ্টা করুন"
            setOnClickListener { runGeminiRequest() }
        }
        root.addView(runButton, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        status = TextView(this).apply {
            text = "প্রথমে API key ও ছবি দিন"
            textSize = 14f
            setTextColor(android.graphics.Color.DKGRAY)
            setPadding(0, 10, 0, 4)
        }
        root.addView(status, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun match(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    private fun runGeminiRequest() {
        val apiKey = keyInput.text.toString().trim()
        val bitmap = selectedBitmap
        val prompt = promptInput.text.toString().trim()
        if (apiKey.isEmpty()) { status.text = "Gemini API key দিন"; return }
        if (bitmap == null) { status.text = "আগে একটি ছবি নির্বাচন করুন"; return }
        if (prompt.isEmpty()) { status.text = "কী পরিবর্তন চান তা লিখুন"; return }

        runButton.isEnabled = false
        status.text = "Gemini-তে অনুরোধ পাঠানো হচ্ছে…"
        thread {
            try {
                val small = resized(bitmap, 1024)
                val bytes = ByteArrayOutputStream().use { out ->
                    small.compress(Bitmap.CompressFormat.JPEG, 88, out)
                    out.toByteArray()
                }
                val imagePart = JSONObject()
                    .put("inline_data", JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", Base64.encodeToString(bytes, Base64.NO_WRAP)))
                val parts = JSONArray()
                    .put(JSONObject().put("text", "Edit the provided image according to this instruction. Return an edited image if supported: $prompt"))
                    .put(imagePart)
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))

                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent?key=$apiKey")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 90000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val responseText = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    .bufferedReader().use { it.readText() }
                if (code !in 200..299) throw Exception("API error $code: ${responseText.take(450)}")
                val json = JSONObject(responseText)
                val candidates = json.optJSONArray("candidates")
                var resultBitmap: Bitmap? = null
                var textMessage = ""
                if (candidates != null && candidates.length() > 0) {
                    val content = candidates.getJSONObject(0).optJSONObject("content")
                    val responseParts = content?.optJSONArray("parts")
                    if (responseParts != null) {
                        for (i in 0 until responseParts.length()) {
                            val part = responseParts.getJSONObject(i)
                            if (part.has("text")) textMessage += part.optString("text") + "\n"
                            val inline = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data")
                            val data = inline?.optString("data")
                            if (!data.isNullOrBlank()) {
                                val decoded = Base64.decode(data, Base64.DEFAULT)
                                resultBitmap = BitmapFactory.decodeByteArray(decoded, 0, decoded.size)
                            }
                        }
                    }
                }
                runOnUiThread {
                    if (resultBitmap != null) {
                        selectedBitmap = resultBitmap
                        imageView.setImageBitmap(resultBitmap)
                        status.text = "Gemini থেকে ছবি এসেছে"
                    } else {
                        status.text = "Gemini-এর উত্তর:\n${textMessage.ifBlank { "ছবির ফল পাওয়া যায়নি। মডেল/ API অ্যাক্সেস পরীক্ষা করুন।" }.take(1200)}"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "অনুরোধ ব্যর্থ: ${e.message?.take(500) ?: "অজানা সমস্যা"}" }
            } finally {
                runOnUiThread { runButton.isEnabled = true }
            }
        }
    }

    private fun resized(src: Bitmap, maxSide: Int): Bitmap {
        val largest = maxOf(src.width, src.height)
        if (largest <= maxSide) return src
        val scale = maxSide.toFloat() / largest
        return Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
    }
}
