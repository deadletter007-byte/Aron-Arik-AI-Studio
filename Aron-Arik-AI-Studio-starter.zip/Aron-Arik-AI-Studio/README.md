# Aron & Arik AI Studio — starter Android project

This is a **starter project**, not a finished Photoshop replacement. It contains:
- Android image picker
- Prompt field
- Gemini image-generation/editing API request scaffold
- Result image preview
- GitHub Actions workflow to build a debug APK

## Important
1. A Google Gemini API key is required.
2. Do not publish a real API key in a public repository or permanently inside a public APK. For a public app, route requests through a secure backend.
3. Gemini image model availability and API access depend on the Google AI Studio account and current API/model access.
4. Layers, masks, Pen Tool, object removal and other advanced editor tools are **not implemented yet**.

## Build with GitHub Actions
Upload the *contents* of this folder to the root of your GitHub repository (not the ZIP file itself), keeping the folder structure. Then open **Actions → Build Android APK** and run the workflow. Download the `app-debug-apk` artifact after a successful run.
