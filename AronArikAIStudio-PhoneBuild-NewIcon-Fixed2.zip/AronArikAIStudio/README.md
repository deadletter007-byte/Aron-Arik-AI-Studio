# Aron & Arik AI Studio

Phone-friendly Android photo editor starter, version 0.2.0.

Implemented offline editing features:
- Open a photo from device storage
- Brightness, contrast, and saturation adjustments
- Rotate preview and export rotated image
- Center square crop
- Add a simple text overlay
- Reset adjustments
- Export edited image as JPEG through Android's Save dialog

AI Edit, automatic background cutout, and AI enhancement are not connected to an AI service in this version.

## Build
The GitHub Actions workflow `.github/workflows/android-apk.yml` builds a debug APK using Java 17 and Gradle 8.9.
