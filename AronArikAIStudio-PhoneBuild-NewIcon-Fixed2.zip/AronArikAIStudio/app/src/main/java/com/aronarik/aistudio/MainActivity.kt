package com.aronarik.aistudio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix as AndroidColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

private val Ink = Color(0xFF0A0B10)
private val Panel = Color(0xFF151821)
private val Violet = Color(0xFF9B7BFF)
private val Cyan = Color(0xFF54D6D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioApp() }
    }
}

@Composable
private fun StudioApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var original by remember { mutableStateOf<Bitmap?>(null) }
    var status by remember { mutableStateOf("Open a photo to start editing.") }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableIntStateOf(0) }
    var squareCrop by remember { mutableStateOf(false) }
    var overlayText by remember { mutableStateOf("") }
    var showTextLayer by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var showAiDialog by remember { mutableStateOf(false) }
    var aiPrompt by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }

    val openPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) {
            status = "No photo selected."
        } else {
            busy = true
            scope.launch {
                val loaded = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    } catch (_: Exception) { null }
                }
                original = loaded
                brightness = 0f
                contrast = 1f
                saturation = 1f
                rotation = 0
                squareCrop = false
                busy = false
                status = if (loaded != null) "Photo opened. Changes are previewed as you edit." else "Could not open this image."
            }
        }
    }

    val savePhoto = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        val source = original
        if (uri == null || source == null) {
            if (uri == null) status = "Save cancelled."
        } else {
            busy = true
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    try {
                        val rendered = renderBitmap(source, brightness, contrast, saturation, rotation, squareCrop, overlayText.takeIf { showTextLayer })
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            rendered.compress(Bitmap.CompressFormat.JPEG, 95, out)
                        } ?: false
                    } catch (_: Exception) { false }
                }
                busy = false
                status = if (result) "Edited photo saved successfully." else "Could not save photo."
            }
        }
    }

    val previewFilter = remember(brightness, contrast, saturation) {
        ColorFilter.colorMatrix(ColorMatrix(makeColorMatrix(brightness, contrast, saturation)))
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Violet,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).background(Brush.linearGradient(listOf(Violet, Cyan)), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Text("A²", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ARON & ARIK", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("AI STUDIO", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    if (busy) CircularProgressIndicator(Modifier.size(24.dp), color = Cyan, strokeWidth = 2.dp)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { openPhoto.launch("image/*") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                        Text("Open Photo")
                    }
                    OutlinedButton(
                        onClick = { if (original != null) savePhoto.launch("AronArik-Edited.jpg") else status = "Open a photo first." },
                        enabled = original != null && !busy, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                    ) { Text("Save JPEG") }
                }

                Button(
                    onClick = { showAiDialog = true },
                    enabled = original != null && !busy,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("AI Edit Photo") }

                Box(
                    Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(18.dp)).background(Color(0xFF101219)),
                    contentAlignment = Alignment.Center
                ) {
                    val bitmap = original
                    if (bitmap == null) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("▧", color = Violet, fontSize = 42.sp)
                            Text("Your photo appears here", color = Color.LightGray)
                            Text("Open Photo to begin", color = Color.Gray, fontSize = 12.sp)
                        }
                    } else {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Photo editing preview",
                            modifier = Modifier.fillMaxSize().padding(8.dp).graphicsLayer(rotationZ = rotation.toFloat()),
                            contentScale = if (squareCrop) ContentScale.Crop else ContentScale.Fit,
                            colorFilter = previewFilter
                        )
                        if (showTextLayer && overlayText.isNotBlank()) {
                            Text(
                                overlayText, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp)
                                    .background(Color(0x66000000), RoundedCornerShape(8.dp)).padding(8.dp)
                            )
                        }
                    }
                }

                Text("EDIT TOOLS", color = Color(0xFF9FA3B7), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToolButton("Rotate 90°", original != null) { rotation = (rotation + 90) % 360 }
                    ToolButton(if (squareCrop) "Fit image" else "Square crop", original != null) { squareCrop = !squareCrop }
                    ToolButton("Add text layer", original != null) { showTextLayer = !showTextLayer }
                    ToolButton("Reset", original != null) {
                        brightness = 0f; contrast = 1f; saturation = 1f; rotation = 0; squareCrop = false; showTextLayer = false; overlayText = ""
                    }
                }

                if (original != null) {
                    Column(Modifier.fillMaxWidth().heightIn(max = 190.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        AdjustmentSlider("Brightness", brightness, -0.5f, 0.5f, { brightness = it }, "${(brightness * 100).toInt()}")
                        AdjustmentSlider("Contrast", contrast, 0.5f, 1.8f, { contrast = it }, "${(contrast * 100).toInt()}%")
                        AdjustmentSlider("Saturation", saturation, 0f, 2f, { saturation = it }, "${(saturation * 100).toInt()}%")
                        if (showTextLayer) {
                            OutlinedTextField(
                                value = overlayText, onValueChange = { overlayText = it },
                                label = { Text("Text layer content") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                } else {
                    Text("Adjustments become available after opening a photo.", color = Color.Gray, fontSize = 12.sp)
                }

                Text(status, color = Cyan, fontSize = 12.sp)
                Text("AI editing uses your own Pollinations API key. Keep the key private; usage may cost credits.", color = Color(0xFF777C90), fontSize = 10.sp)
            }
        }
    }

    if (showAiDialog) {
        AlertDialog(
            onDismissRequest = { if (!busy) showAiDialog = false },
            title = { Text("AI Edit Photo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Describe the changes you want. Example: remove the background and keep the person unchanged.")
                    OutlinedTextField(
                        value = aiPrompt, onValueChange = { aiPrompt = it },
                        label = { Text("What should AI change?") },
                        modifier = Modifier.fillMaxWidth(), minLines = 3
                    )
                    OutlinedTextField(
                        value = apiKey, onValueChange = { apiKey = it },
                        label = { Text("Pollinations API key") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    Text("Use your own key from Pollinations. Never share it with anyone.", fontSize = 11.sp, color = Color.Gray)
                }
            },
            confirmButton = {
                TextButton(enabled = !busy && original != null && aiPrompt.isNotBlank() && apiKey.isNotBlank(), onClick = {
                    val src = original
                    if (src != null) {
                        busy = true
                        status = "Sending photo to AI…"
                        showAiDialog = false
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                try { pollinationsEdit(src, aiPrompt.trim(), apiKey.trim()) }
                                catch (e: Exception) { null }
                            }
                            busy = false
                            if (result != null) {
                                original = result
                                brightness = 0f; contrast = 1f; saturation = 1f; rotation = 0; squareCrop = false
                                status = "AI edit complete. Save JPEG to keep the result."
                            } else {
                                status = "AI edit failed. Check API key, credits, internet, and try again."
                            }
                            apiKey = ""
                        }
                    }
                }) { Text("Run AI Edit") }
            },
            dismissButton = { TextButton(onClick = { showAiDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ToolButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, enabled = enabled, shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
        Text(label, fontSize = 12.sp)
    }
}

@Composable
private fun AdjustmentSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit, valueLabel: String) {
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(valueLabel, color = Cyan, fontSize = 11.sp)
        }
        Slider(value = value, onValueChange = onChange, valueRange = min..max)
    }
}

private fun makeColorMatrix(brightness: Float, contrast: Float, saturation: Float): FloatArray {
    val s = saturation
    val c = contrast
    val offset = (1f - c) * 128f + brightness * 255f
    return floatArrayOf(
        (0.213f + 0.787f * s) * c, (0.715f - 0.715f * s) * c, (0.072f - 0.072f * s) * c, 0f, offset,
        (0.213f - 0.213f * s) * c, (0.715f + 0.285f * s) * c, (0.072f - 0.072f * s) * c, 0f, offset,
        (0.213f - 0.213f * s) * c, (0.715f - 0.715f * s) * c, (0.072f + 0.928f * s) * c, 0f, offset,
        0f, 0f, 0f, 1f, 0f
    )
}

private fun renderBitmap(
    source: Bitmap, brightness: Float, contrast: Float, saturation: Float,
    rotation: Int, squareCrop: Boolean, overlayText: String?
): Bitmap {
    val adjusted = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(adjusted)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    paint.colorFilter = ColorMatrixColorFilter(AndroidColorMatrix(makeColorMatrix(brightness, contrast, saturation)))
    canvas.drawBitmap(source, 0f, 0f, paint)

    var result = adjusted
    if (squareCrop) {
        val side = minOf(result.width, result.height)
        val left = (result.width - side) / 2
        val top = (result.height - side) / 2
        result = Bitmap.createBitmap(result, left, top, side, side)
    }
    if (rotation != 0) {
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        result = Bitmap.createBitmap(result, 0, 0, result.width, result.height, matrix, true)
    }
    if (!overlayText.isNullOrBlank()) {
        val mutable = result.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(mutable)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = (mutable.width * 0.06f).coerceIn(24f, 120f)
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            setShadowLayer(4f, 2f, 2f, android.graphics.Color.BLACK)
        }
        val maxWidth = mutable.width * 0.9f
        val words = overlayText.split(Regex("\\s+"))
        val lines = mutableListOf<String>()
        var line = ""
        for (word in words) {
            val candidate = if (line.isEmpty()) word else "$line $word"
            if (textPaint.measureText(candidate) > maxWidth && line.isNotEmpty()) {
                lines.add(line); line = word
            } else line = candidate
        }
        if (line.isNotEmpty()) lines.add(line)
        val startY = mutable.height - (lines.size * textPaint.textSize * 1.25f) - mutable.height * 0.04f
        lines.forEachIndexed { index, text ->
            c.drawText(text, (mutable.width - textPaint.measureText(text)) / 2f, startY + index * textPaint.textSize * 1.25f, textPaint)
        }
        result = mutable
    }
    return result
}


private fun pollinationsEdit(source: Bitmap, prompt: String, apiKey: String): Bitmap? {
    val imageBytes = ByteArrayOutputStream().use { out ->
        source.compress(Bitmap.CompressFormat.JPEG, 90, out)
        out.toByteArray()
    }
    val boundary = "----AronArikBoundary${System.currentTimeMillis()}"
    val connection = (URL("https://gen.pollinations.ai/v1/images/edits").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 30000
        readTimeout = 120000
        doOutput = true
        setRequestProperty("Authorization", "Bearer $apiKey")
        setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        setRequestProperty("Accept", "image/*, application/json")
    }
    connection.outputStream.use { out ->
        fun field(name: String, value: String) {
            out.write("--$boundary\r\n".toByteArray())
            out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
            out.write(value.toByteArray(Charsets.UTF_8))
            out.write("\r\n".toByteArray())
        }
        field("prompt", prompt)
        field("model", "kontext")
        field("size", "1024x1024")
        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"image\"; filename=\"photo.jpg\"\r\n".toByteArray())
        out.write("Content-Type: image/jpeg\r\n\r\n".toByteArray())
        out.write(imageBytes)
        out.write("\r\n--$boundary--\r\n".toByteArray())
    }
    val code = connection.responseCode
    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
    val responseBytes = stream?.use { it.readBytes() } ?: byteArrayOf()
    if (code !in 200..299) throw IOException("AI request failed: HTTP $code")
    val contentType = connection.contentType.orEmpty()
    connection.disconnect()
    if (contentType.startsWith("image/")) return BitmapFactory.decodeByteArray(responseBytes, 0, responseBytes.size)
    val body = responseBytes.toString(Charsets.UTF_8)
    val imageUrl = try {
        val json = JSONObject(body)
        json.optString("url").takeIf { it.isNotBlank() }
            ?: json.optJSONArray("data")?.optJSONObject(0)?.optString("url")?.takeIf { it.isNotBlank() }
    } catch (_: Exception) { null } ?: throw IOException("AI response did not contain an image")
    val imageConnection = (URL(imageUrl).openConnection() as HttpURLConnection).apply {
        connectTimeout = 30000
        readTimeout = 120000
    }
    return imageConnection.inputStream.use { BitmapFactory.decodeStream(it) }.also { imageConnection.disconnect() }
        ?: throw IOException("Could not decode AI result")
}
