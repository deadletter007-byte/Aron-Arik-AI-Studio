# Aron & Arik AI Studio (starter Android project)

This is an early starter project, not a finished photo editor. It currently contains the initial Android UI only; real AI editing, image-processing tools, and Gemini/OpenAI API integrations still need to be implemented.

## Build an APK using GitHub from an Android phone

1. Create/sign in to a GitHub account at https://github.com/signup.
2. In your browser, open GitHub and create a **new public repository** named `AronArikAIStudio` (a private repository can also work, but public is simpler for a beginner).
3. Open the new repository, choose **Add file → Upload files**, and upload the *contents* of this folder. Ensure `.github/workflows/android-apk.yml` is included. If the phone file picker hides dot-folders or the upload is awkward, use a ZIP extraction/file-manager app to reveal the `.github` folder; do not upload only the ZIP file.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and choose **Build Android APK**. If it has not run automatically, choose **Run workflow**.
6. When the run finishes with a green check, open that run, scroll to **Artifacts**, and download `Aron-Arik-AI-Studio-debug-apk`. Extract the downloaded ZIP to get the APK.

Never share your GitHub password, email verification code, or recovery codes with anyone.
