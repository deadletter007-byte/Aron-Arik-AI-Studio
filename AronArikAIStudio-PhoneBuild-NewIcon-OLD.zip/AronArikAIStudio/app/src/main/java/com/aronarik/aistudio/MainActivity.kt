package com.aronarik.aistudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.net.Uri

private val Ink = Color(0xFF0A0B10)
private val Panel = Color(0xFF151821)
private val Violet = Color(0xFF9B7BFF)
private val Cyan = Color(0xFF54D6D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioApp() }
    }
}

@Composable
fun StudioApp() {
    var selectedImage by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Your creative studio, powered by AI") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedImage = uri
        status = if (uri != null) "Photo selected. Editor tools are the next build milestone." else "No photo selected"
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Violet,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(48.dp).background(
                            Brush.linearGradient(listOf(Violet, Cyan)), RoundedCornerShape(15.dp)
                        ), contentAlignment = Alignment.Center
                    ) { Text("A²", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Black) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ARON & ARIK", fontSize = 12.sp, color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("AI STUDIO", fontSize = 23.sp, color = Color.White, fontWeight = FontWeight.ExtraBold)
                    }
                    Text("V1", color = Violet, fontWeight = FontWeight.Bold)
                }

                Column(
                    modifier = Modifier.fillMaxWidth().background(
                        Brush.linearGradient(listOf(Color(0xFF25203E), Color(0xFF142A31))), RoundedCornerShape(24.dp)
                    ).padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Create beyond limits.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Photo editing made simple. Your ideas, your studio.", color = Color(0xFFD4D5E0), fontSize = 14.sp)
                    Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) {
                        Text("＋   Open a Photo", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                    if (selectedImage != null) Text("Photo ready to edit", color = Cyan, fontSize = 13.sp)
                }

                Text("QUICK TOOLS", color = Color(0xFF9FA3B7), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                val tools = listOf(
                    ToolItem("✦", "AI Edit", "Describe your idea"),
                    ToolItem("☼", "Adjust", "Light & colour"),
                    ToolItem("▧", "Crop", "Frame & rotate"),
                    ToolItem("◈", "Layers", "Build compositions"),
                    ToolItem("✂", "Cutout", "Background tools"),
                    ToolItem("⇧", "Enhance", "Clarity & detail")
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2), modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(tools) { item ->
                        Column(
                            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp))
                                .clickable {
                                    status = when (item.title) {
                                        "AI Edit" -> "AI Edit: type an instruction after opening a photo. AI service connection is not enabled yet."
                                        "Adjust" -> "Adjust tools are planned for the next editor milestone."
                                        "Crop" -> "Crop and rotate are planned for the next editor milestone."
                                        "Layers" -> "Layer stack foundation is planned for the next editor milestone."
                                        "Cutout" -> "Background removal needs an AI image service."
                                        else -> "Enhancement needs an image-processing engine."
                                    }
                                }.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(item.icon, color = Violet, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text(item.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text(item.subtitle, color = Color(0xFF9FA3B7), fontSize = 12.sp)
                        }
                    }
                }
                Text(status, color = Color(0xFFB8BAC9), fontSize = 12.sp)
                Text("Made for your imagination  •  Aron & Arik", color = Color(0xFF656A7D), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

data class ToolItem(val icon: String, val title: String, val subtitle: String)
